from django.shortcuts import render
from django.http import HttpResponse
from.models import Product


# Create your views here.

def index(request):
    products = Products.objects.all()
    return render(request,'index.html',{'products':products})
    #return HttpResponse("<h1>welcome</h1>")


def about(request):
    return HttpResponse("<h1>About Page</h1>")
